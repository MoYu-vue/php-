-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- 主机： localhost
-- 生成日期： 2024-12-06 21:49:55
-- 服务器版本： 5.7.26
-- PHP 版本： 7.3.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 数据库： `blog`
--

-- --------------------------------------------------------

--
-- 表的结构 `articles`
--

CREATE TABLE `articles` (
  `articleid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `categoryid` int(11) NOT NULL,
  `headline` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `content` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `thumbnail` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `credit` int(11) NOT NULL DEFAULT '0',
  `readcount` int(11) NOT NULL DEFAULT '0',
  `replycount` int(11) NOT NULL DEFAULT '0',
  `recommended` tinyint(4) NOT NULL DEFAULT '0',
  `hide` tinyint(4) NOT NULL DEFAULT '0',
  `drafted` tinyint(4) NOT NULL DEFAULT '0',
  `checked` tinyint(4) NOT NULL DEFAULT '1',
  `create_time` datetime NOT NULL,
  `update_time` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 转存表中的数据 `articles`
--

INSERT INTO `articles` (`articleid`, `userid`, `categoryid`, `headline`, `content`, `thumbnail`, `credit`, `readcount`, `replycount`, `recommended`, `hide`, `drafted`, `checked`, `create_time`, `update_time`) VALUES
(1, 1, 1, '漫谈：强哥关于程序设计学习和实战经验分享', '<p>					</p><p>强哥的学习经验，非学简单，就一个字：</p><p><span style=\"font-family: 楷体,楷体_GB2312,SimKai;\"><strong><span style=\"font-size: 400px;\">干</span></strong></span></p><p>每天写它100行代码，每天写，当你积累了20000行代码后，自然就有感觉了。当你积累了100000行代码后，你就是高手了。<br/></p><p><br/></p><p>\n				</p>', '5.jpg', 1, 22, 10, 1, 0, 0, 1, '2017-11-10 12:33:26', '2024-12-06 21:49:11'),
(2, 2, 2, '管理：强哥关于人才培养方面的实战经验分享', '<p>					</p><p><br/></p><p>这篇文章写起来还是挺不容易的，我准备先把这个题目放出来，尽快完成文章内容的编写，敬请期待。</p><p><br/></p><p><br/></p><p>\n				</p>', '6.jpg', 0, 962, 0, 0, 0, 0, 1, '2017-11-10 12:35:56', '2017-11-20 16:49:00'),
(3, 1, 3, '管理：search强哥test关于人才培养方面的keyword实战经验分享', '<p>					</p><p><br/></p><p>这篇文章写起来还是挺不容易的，我准备先把这个题目放出来，尽快完成文章内容的编写，敬请期待。</p><p><br/></p><p><br/></p><p>\r\n				</p>', '6.jpg', 0, 962, 0, 0, 0, 0, 1, '2017-11-10 12:35:56', '2017-11-20 16:49:00'),
(4, 10, 2, '啊啊啊', '啊啊啊啊啊啊', '/storage/20241206/b00817889a7bad88ad17c472a3b569cd.jpg', 0, 2, 0, 0, 0, 0, 1, '2024-12-06 20:38:31', '2024-12-06 20:42:09');

-- --------------------------------------------------------

--
-- 表的结构 `categories`
--

CREATE TABLE `categories` (
  `categoryid` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `create_time` datetime NOT NULL,
  `update_time` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- 转存表中的数据 `categories`
--

INSERT INTO `categories` (`categoryid`, `name`, `create_time`, `update_time`) VALUES
(1, 'PHP开发', '2024-08-28 00:00:00', '2024-08-28 00:00:00'),
(2, 'Java开发', '2024-08-28 00:00:00', '2024-08-28 00:00:00'),
(3, 'Python开发', '2024-08-28 00:00:00', '2024-08-28 00:00:00'),
(4, 'Web前端', '2024-08-28 00:00:00', '2024-08-28 00:00:00'),
(5, '测试开发', '2024-08-28 00:00:00', '2024-08-28 00:00:00'),
(6, '数据科学', '2024-08-28 00:00:00', '2024-08-28 00:00:00'),
(7, '网络安全', '2024-08-28 00:00:00', '2024-08-28 00:00:00');

-- --------------------------------------------------------

--
-- 表的结构 `comments`
--

CREATE TABLE `comments` (
  `commentid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `articleid` int(11) NOT NULL,
  `content` text NOT NULL,
  `ipaddr` varchar(255) NOT NULL,
  `replyid` int(11) NOT NULL,
  `agreecount` int(11) NOT NULL DEFAULT '0',
  `opposecount` int(11) NOT NULL DEFAULT '0',
  `hide` tinyint(4) NOT NULL DEFAULT '0',
  `create_time` datetime NOT NULL,
  `update_time` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- 转存表中的数据 `comments`
--

INSERT INTO `comments` (`commentid`, `userid`, `articleid`, `content`, `ipaddr`, `replyid`, `agreecount`, `opposecount`, `hide`, `create_time`, `update_time`) VALUES
(1, 10, 1, '12345', '127.0.0.1', 0, 0, 0, 0, '2024-12-06 21:49:06', '2024-12-06 21:49:06'),
(2, 10, 1, 'abcde', '127.0.0.1', 1, 0, 0, 0, '2024-12-06 21:49:11', '2024-12-06 21:49:11');

-- --------------------------------------------------------

--
-- 表的结构 `credits`
--

CREATE TABLE `credits` (
  `creditid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `category` varchar(10) NOT NULL,
  `target` int(11) NOT NULL,
  `credit` int(11) NOT NULL,
  `create_time` datetime NOT NULL,
  `update_time` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- 转存表中的数据 `credits`
--

INSERT INTO `credits` (`creditid`, `userid`, `category`, `target`, `credit`, `create_time`, `update_time`) VALUES
(1, 9, '用户注册', 0, 50, '2024-09-29 16:48:36', '2024-09-29 16:48:36'),
(2, 9, '用户登录', 0, 1, '2024-09-29 16:49:38', '2024-09-29 16:49:38'),
(3, 9, '用户登录', 0, 1, '2024-09-29 16:54:17', '2024-09-29 16:54:17'),
(4, 9, '用户登录', 0, 1, '2024-09-29 16:59:34', '2024-09-29 16:59:34'),
(5, 9, '用户登录', 0, 1, '2024-09-29 17:00:16', '2024-09-29 17:00:16'),
(6, 9, '用户登录', 0, 1, '2024-09-29 17:02:02', '2024-09-29 17:02:02'),
(7, 9, '用户登录', 0, 1, '2024-09-29 17:07:44', '2024-09-29 17:07:44'),
(8, 1, '用户登录', 0, 1, '2024-10-11 16:51:40', '2024-10-11 16:51:40'),
(9, 1, '用户登录', 0, 1, '2024-10-11 17:02:23', '2024-10-11 17:02:23'),
(10, 1, '用户登录', 0, 1, '2024-10-11 17:12:56', '2024-10-11 17:12:56'),
(11, 1, '阅读文章', 1, -1, '2024-10-25 16:32:22', '2024-10-25 16:32:22'),
(12, 10, '用户注册', 0, 50, '2024-10-25 16:34:50', '2024-10-25 16:34:50'),
(13, 11, '用户注册', 0, 50, '2024-11-08 21:26:07', '2024-11-08 21:26:07'),
(14, 11, '用户登录', 0, 1, '2024-11-08 21:26:23', '2024-11-08 21:26:23'),
(15, 11, '添加评论', 1, 2, '2024-11-08 21:42:49', '2024-11-08 21:42:49'),
(16, 10, '用户登录', 0, 1, '2024-11-15 20:11:51', '2024-11-15 20:11:51'),
(17, 10, '阅读文章', 1, -1, '2024-11-15 20:16:56', '2024-11-15 20:16:56'),
(18, 10, '用户登录', 0, 1, '2024-12-06 20:07:41', '2024-12-06 20:07:41'),
(19, 10, '用户登录', 0, 1, '2024-12-06 20:29:04', '2024-12-06 20:29:04'),
(20, 10, '用户登录', 0, 1, '2024-12-06 20:29:32', '2024-12-06 20:29:32'),
(21, 10, '用户登录', 0, 1, '2024-12-06 21:11:48', '2024-12-06 21:11:48'),
(22, 10, '添加评论', 1, 2, '2024-12-06 21:15:45', '2024-12-06 21:15:45'),
(23, 10, '添加评论', 1, 2, '2024-12-06 21:28:57', '2024-12-06 21:28:57'),
(24, 10, '添加评论', 1, 2, '2024-12-06 21:39:29', '2024-12-06 21:39:29'),
(25, 10, '添加评论', 1, 2, '2024-12-06 21:44:10', '2024-12-06 21:44:10'),
(26, 10, '添加评论', 1, 2, '2024-12-06 21:49:06', '2024-12-06 21:49:06'),
(27, 10, '添加评论', 1, 2, '2024-12-06 21:49:11', '2024-12-06 21:49:11');

-- --------------------------------------------------------

--
-- 表的结构 `favorites`
--

CREATE TABLE `favorites` (
  `favoriteid` int(11) NOT NULL,
  `articleid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `canceled` tinyint(4) NOT NULL DEFAULT '0',
  `create_time` datetime NOT NULL,
  `update_time` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- 转存表中的数据 `favorites`
--

INSERT INTO `favorites` (`favoriteid`, `articleid`, `userid`, `canceled`, `create_time`, `update_time`) VALUES
(1, 1, 10, 0, '2024-12-06 21:18:27', '2024-12-06 21:18:33');

-- --------------------------------------------------------

--
-- 表的结构 `opinions`
--

CREATE TABLE `opinions` (
  `opinionid` int(11) NOT NULL,
  `commentid` int(11) NOT NULL,
  `userid` int(11) NOT NULL DEFAULT '0',
  `category` tinyint(4) NOT NULL,
  `ipaddr` varchar(225) NOT NULL,
  `create_time` datetime NOT NULL,
  `update_time` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- 转存表中的数据 `opinions`
--

INSERT INTO `opinions` (`opinionid`, `commentid`, `userid`, `category`, `ipaddr`, `create_time`, `update_time`) VALUES
(1, 1, 11, 1, '127.0.0.1', '2024-11-08 21:27:14', '2024-11-08 21:27:14'),
(2, 1, 10, 1, '127.0.0.1', '2024-12-06 21:24:41', '2024-12-06 21:24:41');

-- --------------------------------------------------------

--
-- 表的结构 `users`
--

CREATE TABLE `users` (
  `userid` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(32) NOT NULL,
  `nickname` varchar(30) DEFAULT NULL,
  `avatar` text,
  `qq` varchar(20) DEFAULT NULL,
  `role` varchar(10) NOT NULL DEFAULT '50',
  `credit` int(11) NOT NULL,
  `token` varchar(100) DEFAULT NULL,
  `expire_time` bigint(11) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `update_time` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- 转存表中的数据 `users`
--

INSERT INTO `users` (`userid`, `username`, `password`, `nickname`, `avatar`, `qq`, `role`, `credit`, `token`, `expire_time`, `create_time`, `update_time`) VALUES
(1, 'text1', 'e10adc3949ba59abbe56e057f20f883e', 'text1', '', '', 'user', 59, 'a090a96b20e84d62ec39679b76824aae9f58aa623ca6fc146fdf969e0bae5352', 1729852322, '2024-09-29 16:48:36', '2024-10-25 16:32:02'),
(10, 'test', 'e10adc3949ba59abbe56e057f20f883e', 'test', NULL, '', 'admin', 66, 'b7b85d291d187c4180f3cf80e856702c6e4f77e3b5cffd7cca87e1f5761a9b77', 1733497907, '2024-10-25 16:34:50', '2024-12-06 21:49:11'),
(11, 'test2', 'e10adc3949ba59abbe56e057f20f883e', 'test2', '', '', 'user', 53, '57a91fe0308fb0bac86f5de7fe7fdf96afd91269febc3770d6f67586420e08d1', 1731079583, '2024-11-08 21:26:07', '2024-11-08 21:42:49');

--
-- 转储表的索引
--

--
-- 表的索引 `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`articleid`);

--
-- 表的索引 `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`categoryid`);

--
-- 表的索引 `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`commentid`);

--
-- 表的索引 `credits`
--
ALTER TABLE `credits`
  ADD PRIMARY KEY (`creditid`);

--
-- 表的索引 `favorites`
--
ALTER TABLE `favorites`
  ADD PRIMARY KEY (`favoriteid`);

--
-- 表的索引 `opinions`
--
ALTER TABLE `opinions`
  ADD PRIMARY KEY (`opinionid`);

--
-- 表的索引 `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userid`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `articles`
--
ALTER TABLE `articles`
  MODIFY `articleid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- 使用表AUTO_INCREMENT `categories`
--
ALTER TABLE `categories`
  MODIFY `categoryid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- 使用表AUTO_INCREMENT `comments`
--
ALTER TABLE `comments`
  MODIFY `commentid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- 使用表AUTO_INCREMENT `credits`
--
ALTER TABLE `credits`
  MODIFY `creditid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- 使用表AUTO_INCREMENT `favorites`
--
ALTER TABLE `favorites`
  MODIFY `favoriteid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- 使用表AUTO_INCREMENT `opinions`
--
ALTER TABLE `opinions`
  MODIFY `opinionid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- 使用表AUTO_INCREMENT `users`
--
ALTER TABLE `users`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
