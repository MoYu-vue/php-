<?php

use think\facade\Route;

Route::get('think', function () {
    return 'hello,ThinkPHP6!';
});

Route::get('hello/:name', 'index/hello');

Route::group('auth', function () {
    Route::get('captcha', 'auth/captcha');
    Route::post('register', 'auth/register');
    Route::post('login', 'auth/login');
    Route::get('logout', 'auth/logout');
});

Route::group('article', function () {
    Route::get('list', 'article/list');
    Route::get('page/:page', 'article/page');
    Route::get('type/:type/:page', 'article/type');
    Route::get('search/:keyword/:page', 'article/search');
    Route::get('recommened', 'article/recommened');
    Route::get('read/:articleid', 'article/read');
    Route::post('readall', 'article/readAll');
    Route::post('add', 'article/add');
});

Route::group('favorite', function () {
    Route::get(':articleid', 'Favorite/add');
    Route::delete(':articleid', 'Favorite/cancel');
});

Route::group('comment', function () {
    Route::post('add', 'comment/add');
    Route::post('reply', 'comment/reply');
    Route::get('list/:articleid/:page', 'Comment/list');
    Route::post('opinion', 'Comment/opinion');
    Route::get('hide/:commentid', 'comment/hide');
});

Route::post('upload', 'upload/add');