<?php

namespace app\controller;

use app\model\Articles;
use app\model\Credits;
use app\model\Favorites;
use app\model\Users;
use app\RestBaseController;
use Exception;
use think\Validate;

class Article extends RestBaseController
{
    public function list()
    {
        $article = new Articles();
        $result = $article->findLimitiWithUser(0, 10);
        $this->success('成功', ['list' => $result]);
    }

    public function page($page)
    {
        $pagesize = 10;
        $start = ($page - 1) * $pagesize;
        $article = new Articles();
        $result = $article->findLimitiWithUser($start, $pagesize);
        $total = $article->getTotalCount();
        $paging = ['page' => $page, 'pagesize' => $pagesize, 'total' => $total];
        $this->success('成功', ['paging' => $paging, 'list' => $result]);
    }

    public function type($type, $page)
    {
        $pagesize = 10;
        $start = ($page - 1) * $pagesize;
        $article = new Articles();
        $result = $article->findByCategory($type, $start, $pagesize);
        $total = $article->getCountByCategory($type);
        $paging = ['page' => $page, 'pagesize' => $pagesize, 'total' => $total];
        $this->success('成功', ['paging' => $paging, 'list' => $result]);
    }

    public function search($keyword, $page)
    {
        $validate = new Validate();
        $validate->rule([
            'keyword' => 'require|chsAlphaNum',
        ]);
        $validate->massage([
            'keyword.require' => '请输入关键词',
            'keyword.chsAlphaNum' => '输入的关键词非法',
        ]);

        $data = $this->request->param();
        if (!$validate->check($data)) {
            $this->error($validate->getError());
        }

        $pagesize = 10;
        $start = ($page - 1) * $pagesize;
        $article = new Articles();
        $result = $article->findByHeadline($keyword, $start, $pagesize);
        $total = $article->getCountByKeyword($keyword);
        $paging = ['page' => $page, 'pagesize' => $pagesize, 'total' => $total];
        $this->success('成功', ['paging' => $paging, 'list' => $result]);
    }


    public function recommend()
    {
        $article = new Articles();

        $last = $article->findLast9();
        $most = $article->findMost9();
        $recommended = $article->findRecommendecd9();

        $this->success('成功', ['last' => $last, 'most' => $most, 'recommended' => $recommended]);
    }
    public function read($articleid)
    {
        $article = new Articles();
        $result = $article->findByArticleId($articleid);
        if (count($result) != 1) {
            $this->error('没有找到文章');
        }
        $article->updateReadCount($articleid);
        $position = 0;
        $paied = true;
        if ($result['0']['credit'] > 0) {
            $credit = new Credits();
            $paied = $credit->checkPaiedArticle($this->userId, $articleid);
            if (!$paied) {
                $content = $result['0']['content'];
                $temp = mb_substr($content, 0, ceil(mb_strlen($content, 'UTF-8') / 2), 'UTF-8');
                $position = mb_strrpos($temp, '</p>', 0, 'UTF-8') + 4;
                $result['0']['content'] = mb_substr($content, 0, $position, 'UTF-8');
            }
        }
        $favorite = new Favorites();
        $favorited = $favorite->checkFavorite($this->userId, $articleid);
        $prev_next = $article->findPreNextByid($articleid);
        $this->success('成功', ['article' => $result, 'postition' => $position, 'paied' => $paied, 'favorited' => $favorited, 'prev_next' => $prev_next]);
    }

    public function readAll()
    {
        $position = request()->post('position');
        $articleid = request()->post('articleid');
        $article = new Articles();
        $result = $article->findByArticleId($articleid);

        $user = new Users();
        $user_credit = $user->findByUserid($this->getUserId())->credit;
        if ($user_credit < $result['0']['content']) {
            $this->error('积分不足');
        }
        $content = mb_substr($result['0']['content'], $position, NULL, 'UTF-8');

        $credit = new Credits();
        $paied = $credit->checkPaiedArticle($this->getUserId(), $articleid);
        if (!$paied) {
            $credit->insertDetail($this->getUserId(), '阅读文章', $articleid, -1 * $result['0']['credit']);
            $user->updateCredit($this->getUserId(), -1 * $result['0']['credit']);
        }
        $this->success('成功', ['content' => $content]);
    }

    public function add()
    {
        $validate = new Validate();
        $validate->rule([
            'categoryid' => 'require|integer',
            'headline' => 'require',
            'content' => 'require',
            'thumbnail' => 'require',
            'credit' => 'require|integer',
            'drafted' => 'integer',
            'checked' => 'integer',
            'articleid' => 'integer',
        ]);
        $validate->massage([
            'categoryid.require' => '请输入分类ID',
            'categoryid.integer' => '请输入整数分类ID',
            'headline.require' => '请输入标题',
            'content.require' => '请输入内容',
            'thumbnail.require' => '请输入缩略图',
            'credit.require' => '请输入积分',
            'credit.integer' => '请输入整数积分',
            'drafted.integer' => '请输入整数草稿状态',
            'checked.integer' => '请输入整数审核状态',
            'articleid.integer' => '请输入整数文章ID',
        ]);

        $data = $this->request->param();
        if (!$validate->check($data)) {
            $this->error($validate->getError());
        }

        $this->checkPost();

        $drafted = $data['drafted'] ?? 0;
        $checked = $data['checked'] ?? 1;

        try {
            $article = new Articles();
            if (isset($data['articleid'])) {
                $result = $article->updateArticle($data['articleid'], $this->getUserId(), $data['categoryid'], $data['headline'], $data['content'], $data['thumbnail'], $data['credit'], $drafted, $checked);
            } else {
                $result = $article->insertArticle($this->getUserId(), $data['categoryid'], $data['headline'], $data['content'], $data['thumbnail'], $data['credit'], $drafted, $checked);
            }
        } catch (Exception $e) {
            $this->error($e->getMessage());
        }
        $this->read($result->articleid);
    }
}
