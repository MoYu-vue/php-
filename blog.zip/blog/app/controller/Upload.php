<?php

namespace app\controller;

use app\RestUserBaseController;
use Exception;
use think\facade\Filesystem;
use think\Validate;

class Upload extends RestUserBaseController
{
    public function add()
    {
        try {
            $validate = new Validate();
            $validate->rule([
                'file' => 'require|file',
            ]);
            $validate->message([
                'file.require' => '请上传文件',
                'file.file' => '请上传一个文件',
            ]);

            $data = $this->request->file();
            if (!$validate->check($data)) {
                $this->error($validate->getError());
            }

            $savename = Filesystem::disk('public')->putFile('/',$data['file']);
            $url = Filesystem::disk('public')->url($savename);

        } catch (Exception $e) {
            $this->error($e->getMessage());
        }
        $this->success('上传成功',['url' => $url]);
    }
}
