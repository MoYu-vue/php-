<?php

namespace app\controller;

use app\model\Articles;
use app\model\Comments;
use app\model\Credits;
use app\model\Users;
use app\model\Opinions;
use app\RestBaseController;
use COM;
use Exception;
use think\Validate;


class Comment extends RestBaseController
{
    public function add()
    {
        $validate = new Validate();
        $validate->rule([
            'articleid' => 'require',
            'content' => 'require|length:5,1000',
        ]);
        $validate->message([
            'articleid.require' => '请输入文章ID',
            'content.require' => '请输入评论内容',
            'content.length' => '评论内容长度在5~1000之间',
        ]);

        $date = $this->request->param();
        if (!$validate->check($date)) {
            $this->error($validate->getError());
        }
        $comment = new Comments();
        $limited = $comment->checkLimitperDay($this->getUserId());
        if (!$limited) {
            try {
                $comment->insertComment($this->getUserId(), $date['articleid'], $date['content']);

                $credit = new Credits();
                $credit->insertDetail($this->getUserId(), '添加评论', $date['articleid'], 2);
                $user = new Users();
                $user->updateCredit($this->getUserId(), 2);
                $article = new Articles();
                $article->updateReplyCount($date['articleid']);
            } catch (Exception $e) {
                $this->error($e->getMessage());
            }
            $this->success('评论成功');
        } else {
            $this->error('评论超次数');
        }
    }




    public function reply()
    {
        $validate = new Validate();
        $validate->rule([
            'articleid' => 'require',
            'commentid' => 'require',
            'content' => 'require|length:5,1000',
        ]);
        $validate->message([
            'articleid.require' => '请输入文章ID',
            'commentid.require' => '请输入评论ID',
            'content.require' => '请输入评论内容',
            'content.length' => '评论内容长度在5~1000之间',
        ]);

        $date = $this->request->param();
        if (!$validate->check($date)) {
            $this->error($validate->getError());
        }
        $comment = new Comments();
        $limited = $comment->checkLimitperDay($this->getUserId());
        if (!$limited) {
            try {
                $comment->insertReply($this->getUserId(), $date['articleid'], $date['commentid'], $date['content']);

                $credit = new Credits();
                $credit->insertDetail($this->getUserId(), '添加评论', $date['articleid'], 2);
                $user = new Users();
                $user->updateCredit($this->getUserId(), 2);
                $article = new Articles();
                $article->updateReplyCount($date['articleid']);
            } catch (Exception $e) {
                $this->error($e->getMessage());
            }
            $this->success('回复成功');
        } else {
            $this->error('评论超次数');
        }
    }
    public function list($articleid, $page)
    {
        $pagesize = 10;
        $start = ($page - 1) * $pagesize;
        $comment = new Comments();
        $result = $comment->getCommentReplyArray($articleid, $start, $pagesize);
        $total = $comment->getCommentCountByArticleId($articleid);
        $paging = ['page' => $page, 'pagesize' => $pagesize, 'total' => $total];
        $this->success('成功', ['paging' => $paging, 'list' => $result]);
    }

    public function opinion()
    {
        $validate = new Validate();
        $validate->rule([
            'commentid' => 'require',
            'type' => 'require',
        ]);
        $validate->message([
            'commentid.require' => '请输入评论ID',
            'type·require' => '请输入点费或反对',
        ]);

        $data = $this->request->param();
        if (!$validate->check($data)) {
            $this->error($validate->getError());
        }
        $opinion = new Opinions();
        $check = $opinion->checkOpinion($this->userId, $data['commentid']);
        if (!$check) {
            $opinion->insertOpinion($this->userId, $data['commentid'], $data['type']);
            $comment = new Comments();
            $comment->updateAgreeOpposeCount($data["commentid"], $data['type']);
            $this->success('成功');
        } else {
            $this->error('已经点赞');
        }
    }

    public function hide($commentid)
    {
        $comment = new Comments();
        $result = $comment->hideComment($commentid);
        if ($result) {
            $this->success('隐藏成功');
        } else {
            $this->error('隐藏受限');
        }
    }
}
