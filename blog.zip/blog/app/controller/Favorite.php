<?php
namespace app\controller;

use app\model\Favorites;
use app\RestUserBaseController;
use Exception;

class Favorite extends RestUserBaseController
{
    public function add($articleid)
    {
        try {
            $favorite = new Favorites();
            $favorite->insertFavorite($this->userId, $articleid);
        }catch(Exception $e) {
            $this->error($e->getMessage());
        }
        $this->success('收藏成功');
    }
    public function cancel($articleid)
    {
        try {
            $favorite = new Favorites();
            $favorite->cancelFavorite($this->userId, $articleid);
        }catch(Exception $e) {
            $this->error($e->getMessage());
        }
        $this->success('取消收藏成功');
    }
}
