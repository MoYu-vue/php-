<?php
namespace app\controller;

use app\model\Credits;
use app\model\Users;
use app\RestBaseController;
use Exception;
use think\captcha\facade\Captcha;
use think\Validate;

class Auth extends RestBaseController
{
    public function captcha()
    {
        return Captcha::create();
    }

    public function register()
    {
        $validate = new Validate();
        $validate->rule([
            'username' => 'require',
            'password' => 'require',
            'captcha' => 'require',
        ]);
        $validate->massage([
            'username.require' => '请输入用户名',
            'password.require' => '请输入密码',
            'captcha.require' => '请输入验证码',
        ]);

        $data = $this->request->param();
        if(!$validate->check($data)){
            $this->error($validate->getError());
        }
        if (!captcha_check($data['captcha'])){
            $this->error('验证码错误');
        }

        $user = new Users();

        if (count($user->findByUsername($data['username'])) >0){
            $this->error('此账号已存在');
        }
        try{
            $user->doRegister($data['username'],$data['password']);
            $credit = new Credits();
            $credit -> insertDetail($user->userid,'用户注册',0,50);
        } catch (Exception $e){
            $this->error($e->getMessage());
        }


        $this->success('注册成功',['user' => $user]);
        
    }
    public function login()
    {
        $validate = new Validate();
        $validate->rule([
            'username' => 'require',
            'password' => 'require',
            'captcha' => 'require',
        ]);
        $validate->massage([
            'username.require' => '请输入用户名',
            'password.require' => '请输入密码',
            'captcha.require' => '请输入验证码',
        ]);

        $data = $this->request->param();
        if(!$validate->check($data)){
            $this->error($validate->getError());
        }
        if (!captcha_check($data['captcha'])){
            $this->error('验证码错误');
        }

        $findUser = Users::where('username', $data['username'])->find();

        if(empty($findUser)){
            $this->error('用户不存在');
        }

        if($findUser->password != md5($data['password'])){
            $this->error('密码不正确');
        }

        $findUser->token = md5(uniqid()) . md5(uniqid());
        $findUser->expire_time = time() + 2*3600;
        $findUser->credit += 1;

        if(!$findUser->save()) {
            $this->error('登陆失败');
        }

        $credit = new Credits();
        $credit -> insertDetail($findUser->userid,'用户登录',0,1);

        $this->success('登陆成功', ['user' => $findUser]);
    }
    public function logout()
    {
        $userId = $this->getUserId();
        $findUser = Users::find($userId);
        $findUser ->token = NULL;
        $findUser->save();

        $this->success('退出成功');
    }
}

