<?php

declare(strict_types=1);

namespace app;

use app\BaseController;
use think\exception\HttpResponseException;
use think\facade\Db;

class RestBaseController extends BaseController
{
    protected $token = '';
    protected $userId = 0;
    protected $user;
    protected $role;
    protected function initialize()
    {
        parent::initialize();
        $this->_initUser();
    }

    public function success($msg = '', $data = '')
    {
        $code = 1;
        $result = [
            'code' => $code,
            'msg' => $msg,
            'data' => $data,
        ];
        $response = json($result);
        throw new HttpResponseException($response);
    }

    public function error($msg = '', $data = '')
    {
        $code = 0;
        if (is_array($msg)) {
            $code = $msg['code'];
            $msg = $msg['msg'];
        }
        $result = [
            'code' => $code,
            'msg' => $msg,
            'data' => $data,
        ];
        $response = json($result);
        throw new HttpResponseException($response);
    }
    public function _initUser()
    {
        $token = $this->request->header('Authorization');

        if (empty($token)) {
            return;
        }


        $token = trim(str_ireplace('bearer', '', $token));


        $this->token = $token;

        $user = Db::name('users')->where('token', $token)->where('expire_time', '>', time())->find();


        if (!empty($user)) {
            $this->user = $user;
            $this->userId = $user['userid'];
            $this->role = $user['role'];
        }
    }

    public function getUserId()
    {
        if (empty($this->userId)) {
            $this->error(['code' => 10001, 'msg' => '用户未登录']);
        }
        return $this->userId;
    }

    public function checkPost()
    {
        if (empty($this->userId)) {
            $this->error(['code' => 10001, 'msg' => '用户未登录']);
        }
        if ($this->role != 'editor' && $this->role != 'admin') {
            $this->error('没有权限');
        }
    }
}
