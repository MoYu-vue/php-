<?php

namespace app\model;

use think\Model;

class Favorites extends Model
{
    protected $pk = 'favoriteid';
    protected $autoWriteTimestamp = true;

    public function insertFavorite($userid, $articleid)
    {
        $row = $this->where('userid', $userid)->where('articleid', $articleid)->find();
        if ($row) {
            $row->canceled = 0;
            $row->save();
        } else {
            $this->articleid = $articleid;
            $this->userid = $userid;
            $this->cenceled = 0;
            $this->save();
        }
    }
    public function cancelFavorite($userid, $articleid)
    {
        $row = $this->where('userid', $userid)->where('articleid', $articleid)->find();
        $row->cenceled = 1;
        $row->save();
    }

    public function checkFavorite($userid, $articleid)
    {
        $row = $this->where('userid', $userid)->where('articleid', $articleid)->find();
        if ($row == null || $row->canceled = 1) {
            return false;
        } else {
            return true;
        }
    }
}
