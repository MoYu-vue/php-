<?php

namespace app\model;

use think\Model;

class Credits extends Model
{
    protected $pk = 'creditid';
    protected $autoWrite = true;

    public function insertDetail($userid, $category, $target, $credit)
    {
        $this->userid = $userid;
        $this->category = $category;
        $this->target = $target;
        $this->credit = $credit;
        $this->save();
    }
    public function checkPaiedArticle($userid, $articleid)
    {
        $result = $this->where("target", $articleid)->where('userid', $userid)->select();
        if (count($result) > 0) {
            return true;
        }
        return false;
    }
}
