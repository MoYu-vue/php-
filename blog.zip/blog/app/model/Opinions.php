<?php
namespace app\model;

use think\Model;

class Opinions extends Model
{
    protected $pk ='opinionid';
    protected $autoWriteTimestamp = true;

    public function insertOpinion($userid, $commentid, $category)
    {
        $this->commentid = $commentid;
        $this->userid = $userid;
        $this->category = $category;
        $this->ipaddr = request()->ip();
        $this->save();
    }

    public function checkOpinion($userid, $commentid)
    {
        if ($userid) {
            $count = $this->where('userid', $userid)->where('commentid', $commentid)->count();
        } else {
            $count = $this->where('ipaddr', request()->ip())->where('commentid', $commentid)->count();
        }

        if ($count > 0) {
            return true;
        } else {
            return false;
        }
    }
}