<?php
namespace app\model;

use think\Model;

class Users extends Model
{
    protected $pk = 'userid';
    protected $autoWriteTimestamp = true;

    public function findByUsername($username)
    {
        $result = $this->where('username',$username)->select();
        return $result;
    }

    public function doRegister($username,$password)
    {
        $this->username = $username;
        $this->password = md5($password);
        $this->nickname = $username;
        $this->avatar = '';
        $this->qq = '';
        $this->role = 'user';
        $this->credit = 50;
        $this->token = md5(uniqid()) . md5(uniqid());
        $this->exprie_time = time() + 2*3600;

        $this->save();
    }
    public function findByUserid($userid)
    {
        $result = $this->find($userid);
        return $result;
    }

    public function updateCredit($userid, $credit)
    {
        $user = $this->find($userid);
        $user->credit += $credit;
        $user->save();
    }
}