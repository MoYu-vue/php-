<?php

namespace app\model;

use think\Model;

class Articles extends Model
{
    protected $pk = 'articleid';
    protected $autoWriteTimestamp = true;

    public function findLimitiWithUser($start, $count)
    {
        $result = $this->alias('a')->join('users u', 'u.userid = a.userid')->join('categories c', 'c.categoryid = a.categoryid')->field('a.*,u.nickname,c.name')->where('a.hide', 0)->where('a.checked', 1)->order('a.articleid', 'desc')->limit($start, $count)->select();
        return $result;
    }

    public function getTotalCount()
    {
        $count = $this->where('hide', 0)->where('drafted', 0)->where('checked', 1)->count();
        return $count;
    }

    public function findByCategory($categoryid, $start, $count)
    {
        $result = $this->alias('a')->join('users u', 'u.userid = a.userid')->join('categories c', 'c.categoryid = a.categoryid')->field('a.*,u.nickname,c.name')->where('a.categoryid', $categoryid)->where('a.hide', 0)->where('a.drafted', 0)->where('a.checked', 1)->order('a.articleid', 'desc')->limit($start, $count)->select();
        return $result;
    }


    public function getCountByCategory($categoryid)
    {
        $count = $this->where('categoryid', $categoryid)->where('hide', 0)->where('drafted', 0)->where('checked', 1)->count();
        return $count;
    }

    public function findByHeadline($keyword, $start, $count)
    {
        $result = $this->alias('a')->join('users u', 'u.userid = a.userid')->join('categories c', 'c.categoryid = a.categoryid')->field('a.*,u.nickname,c.name')->where('a.headline', 'like', "%{$keyword}%")->where('a.hide', 0)->where('a.drafted', 0)->where('a.checked', 1)->order('a.articleid', 'desc')->limit($start, $count)->select();
        return $result;
    }
    public function getCountByKeyword($keyword)
    {
        $count = $this->where('headline', 'like', "%{$keyword}%")->where('hide', 0)->where('drafted', 0)->where('checked', 1)->count();
        return $count;
    }

    public function findLast9()
    {
        $result = $this->where('hide', 0)->where('drafted', 0)->where('checked', 1)->field('articleid,headline')->order('articleid', 'desc')->limit(9)->select();
        return $result;
    }
    public function findMost9()
    {
        $result = $this->where('hide', 0)->where('drafted', 0)->where('checked', 1)->field('articleid,headline')->order('readcount', 'desc')->limit(9)->select();
        return $result;
    }
    public function findRecommended9()
    {
        $result = $this->where('hide', 0)->where('drafted', 0)->where('checked', 1)->where('recommended', 1)->field('articleid,headline')->orderRaw('rand()')->limit(9)->select();
        return $result;
    }
    public function findByArticleId($articleid)
    {
        $result = $this->alias('a')->join('users u', 'u.userid = a.userid')->join('categories c', 'c.categoryid = a.categoryid')->field('a.*,u.nickname,c.name')->where('a.hide', 0)
            ->where('a.drafted', 0)->where('a.checked', 1)->where('a.articleid', $articleid)->select();
        return $result;
    }

    public function updateReadCount($articleid)
    {
        $article = $this->find($articleid);
        $article->readcount += 1;
        $article->save();
    }
    public function findHeadlineById($articleid)
    {
        $result = $this->find($articleid);
        return $result->headline;
    }
    public function findPreNextByid($articleid)
    {
        $prev_next = [];

        $prev = $this->where('hide', 0)->where('drafted', 0)->where('drafted', 1)->where('articleid', '<', $articleid)->order('articleid', 'DESC')->find();
        if ($prev != null) {
            $prev_id = $prev->articleid;
        } else {
            $prev_id = $articleid;
        }
        $prev_next['prev_id'] = $prev_id;
        $prev_next['prev_headline'] = $this->findHeadlineById($prev_id);

        $next = $this->where('hide', 0)->where('drafted', 0)->where('drafted', 1)->where('articleid', '>', $articleid)->order('articleid', 'ASC')->find();
        if ($next != null) {
            $next_id = $next->articleid;
        } else {
            $next_id = $articleid;
        }
        $prev_next['next_id'] = $next_id;
        $prev_next['next_headline'] = $this->findHeadlineById($next_id);

        return $prev_next;

        
    }

    public function updateReplyCount($articleid){
        $article = $this->find($articleid);
        $article->replycount += 1;
        $article->save();
    }
    public function insertArticle($userid,$categoryid,$headline,$content,$thumbnail,$credit,$drafted = 0,$checked = 1)
    {
        $this->userid = $userid;
        $this->categoryid = $categoryid;
        $this->headline = $headline;
        $this->content = $content;
        $this->thumbnail = $thumbnail;
        $this->drafted = $drafted;
        $this->credit = $credit;
        $this->checked = $checked;

        $this->save();
        return $this;
    }

    public function updateArticle($article,$userid,$categoryid,$headline,$content,$thumbnail,$credit,$drafted = 0,$checked = 1)
    {
        $article = $this->find($article);

        $article->userid = $userid;
        $article->categoryid = $categoryid;
        $article->headline = $headline;
        $article->content = $content;
        $article->thumbnail = $thumbnail;
        $article->drafted = $drafted;
        $article->credit = $credit;
        $article->checked = $checked;

        $article->save();
        return $article;
    }
}
