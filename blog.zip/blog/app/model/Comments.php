<?php

namespace app\model;

use think\Model;

class Comments extends Model
{
    protected $pk = 'commentid';
    protected $autoWriteTimestamp = true;

    public function insertComment($userid, $articleid, $content)
    {
        $this->userid = $userid;
        $this->articleid = $articleid;
        $this->replyid = 0;
        $this->content = $content;
        $this->ipaddr = request()->ip();
        $this->save();
    }

    public function findByAritcleId($articleid)
    {
        $result = $this->where('articleid', $articleid)->where('hide', 0)->select();
        return $result;
    }

    public function checkLimitPerDay($userid)
    {
        $start = date('Y-m-d 00:00:00');
        $end = date('Y-m-d 23:59:59');
        $count = $this->where('userid', $userid)->whereBetweenTime('create_time', $start, $end)->count();
        if ($count >= 5) {
            return true;
        } else {
            return false;
        }
    }

    public function insertReply($userid, $articleid, $commentid, $content)
    {
        $this->userid = $userid;
        $this->articleid = $articleid;
        $this->replyid = $commentid;
        $this->content = $content;
        $this->ipaddr = request()->ip();
        $this->save();
    }

    public function findCommentWithUser($articleid, $start, $count)
    {
        $result = $this->alias('c')->join('users u', 'c.userid = u.userid')->where('c.articleid', $articleid)->where('c.hide', 0)->where('c.replyid', 0)->field('c.*, u.username, u.nickname,u.avatar')->order('c.commentid', 'desc')->limit($start, $count)->select();
        return $result;
    }

    public function findReplyWithUser($commentid)
    {
        $result = $this->alias('c')->join('users u', 'c.userid = u.userid')->where('c.replyid', $commentid)->where('c.hide', 0)->field('c.*, u.username,u.nickname,u.avatar')->select();
        return $result;
    }

    public function getCommentReplyArray($articleid, $start, $count)
    {
        $commentArray = $this->findCommentWithUser($articleid, $start, $count);
        foreach ($commentArray as $key => $comment) {
            $replyArray = $this->findReplyWithUser($comment['commentid']);
            $commentArray[$key]['reply_list'] = $replyArray;
        }
        return $commentArray;
    }

    public function getCommentCountByArticleId($articleid)
    {
        $count = $this->where('articleid', $articleid)->where('hide', 0)->where('replyid', 0)->count();
        return $count;
    }

    public function updateAgreeOpposeCount($commentid, $type)
    {
        $comment = $this->find($commentid);
        if ($type == 1) {
            $comment->agreecount += 1;
        } else {
            $comment->opposecount += 1;
        }
        $comment->save();
    }
    public function hideComment($commentid)
    {
        $count = $this->where('replyid', $commentid)->where('hide', 0)->count();
        if ($count > 0) {
            return false;
        } else {
            $comment = $this->find($commentid);
            $comment->hide = 1;
            $comment->save();
            return true;
        }
    }
}
