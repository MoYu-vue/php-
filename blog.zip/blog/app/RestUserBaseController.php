<?php
declare (strict_types = 1);

namespace app;

use app\RestBaseController;


class RestUserBaseController extends RestBaseController {

    protected function initialize()
    {
        parent::initialize();
        if(empty($this->user)){
            $this->error(['code' => 10001, 'msg' => '用户未登录']);
        }
    }

}